<?php
require_once __DIR__.'/db.php';
function require_login(){ if(empty($_SESSION['admin_id'])){ header('Location: index.php'); exit; } }
function login_admin($username,$password){
    $st=db()->prepare('SELECT * FROM admins WHERE username=? LIMIT 1'); $st->execute([$username]); $a=$st->fetch();
    if($a && password_verify($password,$a['password_hash'])){ $_SESSION['admin_id']=$a['id']; $_SESSION['admin_username']=$a['username']; return true; }
    return false;
}
function logout_admin(){ $_SESSION=[]; if(ini_get('session.use_cookies')){ $p=session_get_cookie_params(); setcookie(session_name(),'',['expires'=>time()-42000,'path'=>$p['path'],'domain'=>$p['domain'],'secure'=>$p['secure'],'httponly'=>$p['httponly'],'samesite'=>'Lax']); } session_destroy(); }
