<?php
function e($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function money($v){ return 'S/ '.number_format((float)$v,2,'.',','); }
function date_display($value){ if(!$value) return ''; try { return (new DateTime((string)$value))->format('d/m/y'); } catch(Throwable $e){ return (string)$value; } }
function date_to_db($value){ $value=trim((string)$value); foreach(['!d/m/y','!d/m/Y','!Y-m-d'] as $format){ $d=DateTime::createFromFormat($format,$value); $errors=DateTime::getLastErrors(); if($d && ($errors===false || (!$errors['warning_count'] && !$errors['error_count']))) return $d->format('Y-m-d'); } return false; }
function redirect($url){ header('Location: '.$url); exit; }
function public_url($path=''){ return rtrim(APP_URL,'/').'/'.ltrim($path,'/'); }
function order_balance($orderId){
    $st=db()->prepare('SELECT total FROM orders WHERE id=?'); $st->execute([$orderId]); $total=(float)$st->fetchColumn();
    $st=db()->prepare('SELECT COALESCE(SUM(amount),0) FROM payments WHERE order_id=?'); $st->execute([$orderId]); $paid=(float)$st->fetchColumn();
    return max(0,$total-$paid);
}


function flash($message, $type='success'){
    $_SESSION['flash'] = $message;
    $_SESSION['flash_type'] = $type;
}

function send_system_email($to, $subject, $textBody, $receiptUrl=''){
    $to=trim($to);
    if(!filter_var($to,FILTER_VALIDATE_EMAIL)){
        return ['ok'=>false,'message'=>'El correo del cliente no es válido.'];
    }

    // SMTP recomendado para hosting compartido. Se activa desde config.php.
    if(defined('SMTP_ENABLED') && SMTP_ENABLED){
        return smtp_send_email($to,$subject,$textBody,$receiptUrl);
    }

    $headers='From: '.COMPANY_EMAIL."\r\n".
             'Reply-To: '.COMPANY_EMAIL."\r\n".
             "MIME-Version: 1.0\r\n".
             "Content-Type: text/plain; charset=UTF-8\r\n";
    $ok=@mail($to,$subject,$textBody,$headers);
    if($ok) return ['ok'=>true,'message'=>''];

    return ['ok'=>false,'message'=>'El servidor rechazó mail(). Activa SMTP en config.php y coloca los datos SMTP de tu hosting (host, puerto, usuario y contraseña).'];
}

function smtp_send_email($to,$subject,$textBody,$receiptUrl=''){
    $host=defined('SMTP_HOST') ? trim(SMTP_HOST) : '';
    $port=defined('SMTP_PORT') ? (int)SMTP_PORT : 587;
    $user=defined('SMTP_USER') ? trim(SMTP_USER) : '';
    $pass=defined('SMTP_PASS') ? SMTP_PASS : '';
    $secure=defined('SMTP_SECURE') ? strtolower(trim(SMTP_SECURE)) : 'auto';
    $from=$user; // En cPanel, MAIL FROM debe coincidir con la cuenta autenticada para evitar rechazo.
    $fromName=defined('SMTP_FROM_NAME') && SMTP_FROM_NAME ? SMTP_FROM_NAME : COMPANY_NAME;

    if($host==='' || $user==='' || $pass===''){
        return ['ok'=>false,'message'=>'Falta configurar SMTP en config.php (SMTP_HOST, SMTP_USER y SMTP_PASS).'];
    }
    if(!filter_var($user,FILTER_VALIDATE_EMAIL)){
        return ['ok'=>false,'message'=>'SMTP_USER debe ser una dirección de correo válida.'];
    }

    // AUTO: 465 usa SSL implícito; 587 usa STARTTLS.
    // Si 587 no ofrece STARTTLS, intentamos automáticamente 465/SSL.
    if($secure==='auto') $secure=($port===465 ? 'ssl' : 'tls');

    $attempts=[['port'=>$port,'secure'=>$secure]];
    if($secure==='tls' && $port!==465){
        $attempts[]=['port'=>465,'secure'=>'ssl'];
    } elseif($secure==='ssl' && $port!==465){
        $attempts[]=['port'=>587,'secure'=>'tls'];
    }

    $lastError='No se pudo conectar al servidor SMTP.';
    foreach($attempts as $attempt){
        $result=smtp_send_email_attempt($host,$attempt['port'],$attempt['secure'],$user,$pass,$from,$fromName,$to,$subject,$textBody,$receiptUrl);
        if($result['ok']) return $result;
        $lastError=$result['message'];

        // Solo intentamos la segunda combinación cuando el problema es de transporte/STARTTLS.
        if(strpos($lastError,'STARTTLS')===false && strpos($lastError,'conectar al servidor SMTP')===false && strpos($lastError,'TLS')===false) break;
    }

    return ['ok'=>false,'message'=>$lastError.' Si tu hosting usa cPanel, normalmente prueba puerto 465 con SSL o 587 con STARTTLS.'];
}

function smtp_send_email_attempt($host,$port,$secure,$user,$pass,$from,$fromName,$to,$subject,$textBody,$receiptUrl=''){
    $transportHost=$host;
    if($secure==='ssl' && strpos($transportHost,'://')===false) $transportHost='ssl://'.$transportHost;

    $errno=0; $errstr='';
    $fp=@stream_socket_client($transportHost.':'.$port,$errno,$errstr,15,STREAM_CLIENT_CONNECT);
    if(!$fp) return ['ok'=>false,'message'=>'No se pudo conectar al servidor SMTP en el puerto '.$port.': '.($errstr ?: 'conexión rechazada').'.'];
    stream_set_timeout($fp,15);

    $read=function() use($fp){
        $data='';
        while(($line=fgets($fp,515))!==false){
            $data.=$line;
            if(isset($line[3]) && $line[3]===' ') break;
        }
        return $data;
    };
    $code=function($response){ return (int)substr(trim($response),0,3); };
    $write=function($command) use($fp){ fwrite($fp,$command."\r\n"); };
    $fail=function($message) use($fp){ @fwrite($fp,"QUIT\r\n"); @fclose($fp); return ['ok'=>false,'message'=>$message]; };

    $r=$read(); if($code($r)>=400) return $fail('El servidor SMTP no aceptó la conexión en el puerto '.$port.'.');
    $write('EHLO '.($_SERVER['SERVER_NAME']??'localhost')); $r=$read(); if($code($r)>=400) return $fail('El servidor SMTP rechazó EHLO.');

    if($secure==='tls'){
        $write('STARTTLS'); $r=$read();
        if($code($r)!==220) return $fail('El servidor SMTP no permite STARTTLS en el puerto '.$port.'.');
        if(!stream_socket_enable_crypto($fp,true,STREAM_CRYPTO_METHOD_TLS_CLIENT)) return $fail('No se pudo activar TLS con el servidor SMTP.');
        $write('EHLO '.($_SERVER['SERVER_NAME']??'localhost')); $r=$read(); if($code($r)>=400) return $fail('El servidor SMTP rechazó EHLO después de TLS.');
    }

    $write('AUTH LOGIN'); $r=$read(); if($code($r)!==334) return $fail('El servidor SMTP no permite AUTH LOGIN.');
    $write(base64_encode($user)); $r=$read(); if($code($r)!==334) return $fail('El usuario SMTP fue rechazado.');
    $write(base64_encode($pass)); $r=$read(); if($code($r)!==235) return $fail('La contraseña SMTP fue rechazada.');

    $write('MAIL FROM:<'.$from.'>'); $r=$read(); if($code($r)>=400) return $fail('El servidor SMTP rechazó el correo remitente.');
    $write('RCPT TO:<'.$to.'>'); $r=$read(); if($code($r)>=400) return $fail('El servidor SMTP rechazó el correo del cliente.');
    $write('DATA'); $r=$read(); if($code($r)!==354) return $fail('El servidor SMTP no permitió iniciar el contenido del correo.');

    $safeSubject=str_replace(["\r","\n"],' ',$subject);
    $safeFromName=str_replace(["\r","\n"],' ',$fromName);
    $encodedSubject='=?UTF-8?B?'.base64_encode($safeSubject).'?=';
    $encodedFromName='=?UTF-8?B?'.base64_encode($safeFromName).'?=';
    $htmlBody=nl2br(e($textBody));
    if($receiptUrl!=='') $htmlBody.='<br><br><a href="'.e($receiptUrl).'">Ver comprobante</a>';
    $boundary='bnd_'.bin2hex(random_bytes(8));
    $headers="From: {$encodedFromName} <{$from}>\r\n".
              "To: <{$to}>\r\n".
              "Subject: {$encodedSubject}\r\n".
              "MIME-Version: 1.0\r\n".
              "Content-Type: multipart/alternative; boundary=\"{$boundary}\"\r\n\r\n";
    $message=$headers.
              "--{$boundary}\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: 8bit\r\n\r\n".$textBody."\r\n\r\n".
              "--{$boundary}\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: 8bit\r\n\r\n".$htmlBody."\r\n\r\n".
              "--{$boundary}--\r\n.";
    fwrite($fp,$message."\r\n");
    $r=$read();
    $write('QUIT'); $read(); fclose($fp);
    if($code($r)>=400){
        $detail=trim(preg_replace('/\s+/', ' ', $r));
        if(strlen($detail)>300) $detail=substr($detail,0,300).'...';
        return ['ok'=>false,'message'=>'El servidor SMTP rechazó el mensaje (respuesta '.$code($r).'): '.$detail.' Verifica que SMTP_FROM_EMAIL coincida con SMTP_USER o con una cuenta autorizada en tu hosting.'];
    }
    return ['ok'=>true,'message'=>''];
}
