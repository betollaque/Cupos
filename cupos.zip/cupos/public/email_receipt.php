<?php
require_once __DIR__.'/../includes/auth.php';
require_once __DIR__.'/../includes/helpers.php';
require_login();

$id=(int)($_GET['id']??0);
$st=db()->prepare('SELECT p.*,o.order_number,o.total,o.installments,c.full_name,c.email FROM payments p JOIN orders o ON o.id=p.order_id JOIN clients c ON c.id=o.client_id WHERE p.id=?');
$st->execute([$id]);
$p=$st->fetch();
if(!$p) redirect('orders.php');

if(empty($p['email'])){
    $_SESSION['flash']='El cliente no tiene correo registrado.';
    redirect('order.php?id='.$p['order_id']);
}

$subject='Comprobante de pago - '.$p['order_number'].' - Cuota '.$p['installment_no'];
$url=public_url('receipt.php?id='.$id);
$body="Hola {$p['full_name']},\n\nAdjuntamos el comprobante correspondiente a su cuota {$p['installment_no']} del pedido {$p['order_number']}.\n\nFecha: ".date_display($p['paid_at'])."\nMonto pagado: ".money($p['amount'])."\nMora: ".money($p['late_fee'])."\n\nPuede visualizar o guardar el comprobante aquí:\n{$url}\n\nSaludos,\n".COMPANY_NAME;

$result=send_system_email($p['email'],$subject,$body,$url);
$_SESSION['flash']=$result['ok']
    ? 'Correo enviado correctamente a '.$p['email'].'.'
    : 'No se pudo enviar el correo. '.$result['message'];
redirect('order.php?id='.$p['order_id']);
