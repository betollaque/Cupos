<?php
require 'header.php';
if(!empty($_SESSION['flash'])){echo '<div class="alert success-alert">'.e($_SESSION['flash']).'</div>';unset($_SESSION['flash']);unset($_SESSION['flash_type']);}
$rows=db()->query('SELECT * FROM products ORDER BY name ASC')->fetchAll();
?>
<div class="actions" style="justify-content:space-between"><h1>Almacén</h1><a class="btn primary" href="product_new.php">+ Nuevo producto</a></div>
<div class="card" style="margin-bottom:15px"><label><input type="search" id="productSearch" placeholder="Buscar por producto o proveedor"></label></div>
<div class="card table-wrap"><table id="productsTable">
<tr><th>Producto</th><th>Proveedor</th><th>Precio contado</th><th>Precio crédito</th><th>Stock</th><th>Stock mínimo</th><th>Estado</th><th></th></tr>
<?php foreach($rows as $r): $low=(int)$r['stock'] <= (int)$r['min_stock']; ?>
<tr class="product-line<?=$low?' low-stock':''?>" data-search="<?=e(mb_strtolower($r['name'].' '.($r['supplier'] ?? ''),'UTF-8'))?>">
<td><?=e($r['name'])?></td>
<td><?=e($r['supplier'] ?? '')?></td>
<td><?=money($r['cash_price'])?></td>
<td><?=money($r['credit_price'])?></td>
<td><strong><?=$r['stock']?></strong></td>
<td><?=$r['min_stock']?></td>
<td><?=$r['active']?'Activo':'Inactivo'?><?=$low?' <strong>(Stock bajo)</strong>':''?></td>
<td><a class="btn secondary" href="product_new.php?id=<?=$r['id']?>">Editar</a></td>
</tr>
<?php endforeach;?></table></div>
<style>
.low-stock td{background:#ffd6d6 !important;color:#9b111e;font-weight:600}
#productSearch{width:100%}
</style>
<script>
const search=document.getElementById('productSearch');
search.addEventListener('input',function(){const q=this.value.trim().toLowerCase();document.querySelectorAll('.product-line').forEach(r=>r.style.display=(!q||r.dataset.search.includes(q))?'':'none');});
</script>
<?php require 'footer.php'; ?>
