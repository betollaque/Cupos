</main>
<div id="confirmModal" class="modal" aria-hidden="true">
  <div class="modal-box confirm-box">
    <div class="modal-head"><h2 id="confirmTitle">Confirmar guardado</h2><button type="button" class="modal-close" onclick="closeConfirm()">×</button></div>
    <div class="modal-body"></div>
    <div class="modal-actions"><button type="button" class="btn secondary" onclick="closeConfirm()">Cancelar</button><button type="button" class="btn primary" id="confirmSubmit">Confirmar y guardar</button></div>
  </div>
</div>
<script>
(function(){
let pendingForm=null;
window.openConfirm=function(form,title,text){
  pendingForm=form;
  document.getElementById('confirmTitle').textContent=title||'Confirmar guardado';
  const m=document.getElementById('confirmModal');m.classList.add('show');m.setAttribute('aria-hidden','false');
};
window.closeConfirm=function(){pendingForm=null;const m=document.getElementById('confirmModal');m.classList.remove('show');m.setAttribute('aria-hidden','true');};
document.addEventListener('DOMContentLoaded',function(){
 document.querySelectorAll('.success-alert').forEach(function(alert){
   window.setTimeout(function(){
     alert.style.transition='opacity .25s ease, transform .25s ease';
     alert.style.opacity='0';
     alert.style.transform='translateY(-4px)';
     window.setTimeout(function(){ if(alert.parentNode) alert.parentNode.removeChild(alert); },260);
   },4000);
 });
 document.querySelectorAll('form[data-confirm-save]').forEach(function(form){
   form.addEventListener('submit',function(ev){
     if(form.dataset.confirmed==='1'){form.dataset.confirmed='';return;}
     ev.preventDefault();
     openConfirm(form,form.dataset.confirmTitle,form.dataset.confirmText);
   });
 });
 document.getElementById('confirmSubmit').addEventListener('click',function(){
   if(!pendingForm)return;
   const f=pendingForm;f.dataset.confirmed='1';closeConfirm();f.submit();
 });
 document.getElementById('confirmModal').addEventListener('click',function(e){if(e.target===this)closeConfirm();});
});
})();
</script>
<script src="assets/pwa.js" defer></script>
</body></html>
