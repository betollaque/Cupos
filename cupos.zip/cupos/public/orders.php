<?php
require 'header.php';
if(!empty($_SESSION['flash'])){echo '<div class="alert success-alert">'.e($_SESSION['flash']).'</div>';unset($_SESSION['flash']);unset($_SESSION['flash_type']);}
$rows=db()->query("SELECT o.*,c.full_name FROM orders o JOIN clients c ON c.id=o.client_id ORDER BY o.id DESC")->fetchAll();
?>
<div class="actions" style="justify-content:space-between"><h1>Pedidos</h1><a class="btn primary" href="order_new.php">+ Nuevo pedido</a></div>
<div class="card" style="margin-bottom:15px"><label><input type="search" id="orderSearch" placeholder="Buscar por número, cliente, fecha o estado"></label></div>
<div class="card table-wrap"><table id="ordersTable">
<tr><th>Pedido</th><th>Cliente</th><th>Fecha</th><th>Total</th><th>Plan</th><th>Saldo</th><th>Estado</th><th></th></tr>
<?php foreach($rows as $r):
$statusLabel=['active'=>'activo','completed'=>'completo'];
$statusText=$statusLabel[$r['status']] ?? $r['status'];
$searchText=implode(' ',[$r['order_number'],$r['full_name'],$r['start_date'],date_display($r['start_date']),$r['installments'].' cuotas',$statusText]);
?>
<tr class="order-line" data-search="<?=e(mb_strtolower($searchText,'UTF-8'))?>">
<td><?=e($r['order_number'])?></td><td><?=e($r['full_name'])?></td><td><?=e(date_display($r['start_date']))?></td><td><?=money($r['total'])?></td><td><?=e($r['installments'])?> cuotas</td><td><?=money(order_balance($r['id']))?></td><td><?=e($statusText)?></td><td><a class="btn secondary" href="order.php?id=<?=$r['id']?>">Ver</a></td>
</tr>
<?php endforeach;?></table>
<div id="ordersPagination" class="actions" style="justify-content:space-between;align-items:center;margin-top:15px">
    <small id="ordersPageInfo"></small>
    <div class="actions" style="gap:8px">
        <button type="button" class="btn secondary" id="ordersPrev">Anterior</button>
        <button type="button" class="btn secondary" id="ordersNext">Siguiente</button>
    </div>
</div>
</div>
<style>#orderSearch{width:100%}</style>
<script>
(function(){
    const search=document.getElementById('orderSearch');
    const rows=Array.from(document.querySelectorAll('.order-line'));
    const info=document.getElementById('ordersPageInfo');
    const prev=document.getElementById('ordersPrev');
    const next=document.getElementById('ordersNext');
    const pageSize=10;
    let page=1;

    function render(){
        const q=search.value.trim().toLowerCase();
        const filtered=rows.filter(row=>!q || row.dataset.search.includes(q));
        const pages=Math.max(1,Math.ceil(filtered.length/pageSize));
        page=Math.min(page,pages);
        rows.forEach(row=>row.style.display='none');
        filtered.slice((page-1)*pageSize,page*pageSize).forEach(row=>row.style.display='');
        info.textContent=filtered.length
            ? 'Mostrando '+((page-1)*pageSize+1)+'-'+Math.min(page*pageSize,filtered.length)+' de '+filtered.length+' pedidos · Página '+page+' de '+pages
            : 'No se encontraron pedidos';
        prev.disabled=page<=1;
        next.disabled=page>=pages;
    }

    search.addEventListener('input',function(){page=1;render();});
    prev.addEventListener('click',function(){if(page>1){page--;render();}});
    next.addEventListener('click',function(){page++;render();});
    render();
})();
</script>
<?php require 'footer.php'; ?>
