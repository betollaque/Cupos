<?php
require_once __DIR__.'/../includes/auth.php';
require_once __DIR__.'/../includes/helpers.php';
require_login();
$pdo = db();
$id = (int)($_GET['id'] ?? 0);
$c = $id ? $pdo->query('SELECT * FROM clients WHERE id='.$id)->fetch() : null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $dni = trim($_POST['document']);
    if (!preg_match('/^\d{8}$/', $dni)) {
        $_SESSION['flash'] = 'El DNI debe contener exactamente 8 dígitos.';
        redirect($id ? 'client_new.php?id='.$id : 'client_new.php');
    }
    $data = [trim($_POST['full_name']), $dni, trim($_POST['district']), trim($_POST['phone']), trim($_POST['email']), trim($_POST['address']), trim($_POST['notes'])];
    if ($id) {
        $st = $pdo->prepare('UPDATE clients SET full_name=?,document=?,district=?,phone=?,email=?,address=?,notes=? WHERE id=?');
        $st->execute([...$data, $id]);
        flash('Cliente actualizado correctamente.');
    } else {
        $st = $pdo->prepare('INSERT INTO clients(full_name,document,district,phone,email,address,notes) VALUES(?,?,?,?,?,?,?)');
        $st->execute($data);
        flash('Cliente guardado correctamente.');
    }
    redirect('clients.php');
}
require 'header.php';
?>
<h1><?=$id?'Editar':'Nuevo'?> cliente</h1>
<div class="card"><form method="post" data-confirm-save data-confirm-title="Confirmar cliente" data-confirm-text="¿Deseas guardar este cliente? Al confirmar se guardará y volverás a la pantalla de Clientes.">
<div class="two">
<label>Nombre completo*<input name="full_name" required value="<?=e($c['full_name']??'')?>"></label>
<label>DNI<input name="document" type="text" inputmode="numeric" maxlength="8" pattern="[0-9]{8}" title="Ingresa un DNI de 8 dígitos" required value="<?=e($c['document']??'')?>"></label>
<label>Distrito<input name="district" value="<?=e($c['district']??'')?>"></label>
<label>WhatsApp / teléfono<input name="phone" placeholder="51984169096" value="<?=e($c['phone']??'')?>"></label>
<label>Correo electrónico<input type="email" name="email" value="<?=e($c['email']??'')?>"></label>
<label>Dirección<input name="address" value="<?=e($c['address']??'')?>"></label>
</div>
<label>Notas<textarea name="notes"><?=e($c['notes']??'')?></textarea></label>
<div class="actions"><button type="submit" class="btn primary">Guardar</button><a class="btn secondary" href="clients.php">Cancelar</a></div>
</form></div>
<?php require 'footer.php'; ?>
