<?php
require 'header.php';
if(!empty($_SESSION['flash'])){echo '<div class="alert success-alert">'.e($_SESSION['flash']).'</div>';unset($_SESSION['flash']);unset($_SESSION['flash_type']);}
$rows=db()->query('SELECT * FROM clients ORDER BY id DESC')->fetchAll();
?>
<div class="actions" style="justify-content:space-between"><h1>Clientes</h1><a class="btn primary" href="client_new.php">+ Nuevo cliente</a></div>
<div class="card" style="margin-bottom:15px"><label><input type="search" id="clientSearch" placeholder="Buscar por nombre, DNI, distrito, WhatsApp o correo"></label></div>
<div class="card table-wrap"><table id="clientsTable">
<tr><th>Cliente</th><th>DNI</th><th>Distrito</th><th>WhatsApp</th><th>Correo</th><th></th></tr>
<?php foreach($rows as $r):
$searchText=implode(' ',[$r['full_name'],$r['document'],$r['district'],$r['phone'],$r['email']]);
?>
<tr class="client-line" data-search="<?=e(mb_strtolower($searchText,'UTF-8'))?>">
<td><?=e($r['full_name'])?></td><td><?=e($r['document'])?></td><td><?=e($r['district'])?></td><td><?=e($r['phone'])?></td><td><?=e($r['email'])?></td><td><a class="btn secondary" href="client_new.php?id=<?=$r['id']?>">Editar</a></td>
</tr>
<?php endforeach;?></table></div>
<style>#clientSearch{width:100%}</style>
<script>
const clientSearch=document.getElementById('clientSearch');
clientSearch.addEventListener('input',function(){const q=this.value.trim().toLowerCase();document.querySelectorAll('.client-line').forEach(r=>r.style.display=(!q||r.dataset.search.includes(q))?'':'none');});
</script>
<?php require 'footer.php'; ?>
