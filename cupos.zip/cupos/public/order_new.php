<?php
require_once __DIR__.'/../includes/auth.php';
require_once __DIR__.'/../includes/helpers.php';
require_login();
$pdo = db();
$clients = $pdo->query('SELECT id,full_name FROM clients ORDER BY full_name')->fetchAll();
$products = $pdo->query('SELECT id,name,cash_price,credit_price,stock FROM products WHERE active=1 ORDER BY name')->fetchAll();
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $client = (int)$_POST['client_id'];
    $n = max(1, min(24, (int)$_POST['installments']));
    $start = date_to_db($_POST['start_date'] ?? '');
    if (!$start) $error = 'Ingresa la fecha de inicio en formato dd/mm/yy.';
    $items = [];
    $total = 0;
    $requested = [];
    foreach ($_POST['product_id'] ?? [] as $i => $pid) {
        $pid = (int)$pid;
        $qty = max(1, (int)($_POST['qty'][$i] ?? 1));
        if ($pid > 0) $requested[$pid] = ($requested[$pid] ?? 0) + $qty;
    }

    if (!$error && $client && count($requested)) {
        $checkClient = $pdo->prepare('SELECT id FROM clients WHERE id=? LIMIT 1');
        $checkClient->execute([$client]);
        if (!$checkClient->fetchColumn()) { $error = 'Selecciona un cliente válido de la lista.'; }
    }

    if (!$error && $client && count($requested)) {
        $pdo->beginTransaction();
        try {
            $ids = array_keys($requested);
            $placeholders = implode(',', array_fill(0, count($ids), '?'));
            $stp = $pdo->prepare("SELECT id,name,cash_price,credit_price,stock FROM products WHERE id IN ($placeholders) AND active=1 FOR UPDATE");
            $stp->execute($ids);
            $dbProducts = [];
            foreach ($stp->fetchAll() as $p) $dbProducts[(int)$p['id']] = $p;

            foreach ($requested as $pid => $qty) {
                if (!isset($dbProducts[$pid])) throw new RuntimeException('Uno de los productos seleccionados ya no está disponible.');
                $p = $dbProducts[$pid];
                if ((int)$p['stock'] < $qty) {
                    throw new RuntimeException('Stock insuficiente para "'. $p['name'] .'". Disponible: '.(int)$p['stock'].'.');
                }
                $price = $n === 1 ? (float)$p['cash_price'] : (float)$p['credit_price'];
                if ($price <= 0) throw new RuntimeException('El producto "'.$p['name'].'" no tiene precio configurado para '.($n === 1 ? 'contado' : 'crédito').'.');
                $sub = $qty * $price;
                $items[] = [$pid, $p['name'], $qty, $price, $sub];
                $total += $sub;
            }

            if ($total <= 0 || !count($items)) throw new RuntimeException('Selecciona al menos un producto válido.');
            $orderNo = 'PED-'.date('YmdHis').'-'.random_int(100,999);
            $installment = round($total/$n, 2);
            $st = $pdo->prepare('INSERT INTO orders(order_number,client_id,total,installments,installment_amount,start_date,notes) VALUES(?,?,?,?,?,?,?)');
            $st->execute([$orderNo, $client, $total, $n, $installment, $start, trim($_POST['notes'] ?? '')]);
            $oid = $pdo->lastInsertId();
            $sti = $pdo->prepare('INSERT INTO order_items(order_id,product_id,product_name,quantity,unit_price,subtotal) VALUES(?,?,?,?,?,?)');
            $sts = $pdo->prepare('UPDATE products SET stock = stock - ? WHERE id = ? AND stock >= ?');
            foreach ($items as $it) {
                $sti->execute([$oid, ...$it]);
                $sts->execute([$it[2], $it[0], $it[2]]);
                if ($sts->rowCount() !== 1) throw new RuntimeException('No se pudo actualizar el stock de "'.$it[1].'".');
            }
            $pdo->commit();
            flash('Pedido guardado correctamente y stock actualizado.');
            redirect('orders.php');
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $error = $e->getMessage();
        }
    } elseif (!$error) {
        $error = 'Selecciona un cliente y al menos un producto.';
    }
}
require 'header.php';
?>
<h1>Nuevo pedido</h1>
<?php if(!empty($error)): ?><div class="alert danger"><?=e($error)?></div><?php endif; ?>
<div class="card"><form method="post" data-confirm-save data-confirm-title="Confirmar pedido" data-confirm-text="¿Deseas crear este pedido? Al confirmar se guardará y se descontará el stock." id="orderForm">
<div class="three"><label>Cliente*<div class="predictive-client" style="position:relative"><input type="text" id="clientSearch" placeholder="Escribe el nombre del cliente..." autocomplete="off" value="<?=e($_POST['client_id'] ?? '') ? e((string)($clients[array_search((int)($_POST['client_id'] ?? 0), array_column($clients, 'id'))]['full_name'] ?? '')) : ''?>" required><input type="hidden" name="client_id" id="clientId"><div id="clientSuggestions" class="client-suggestions" style="display:none;position:absolute;z-index:20;left:0;right:0;max-height:220px;overflow:auto;background:#fff;border:1px solid #ccc;border-radius:6px"></div></div></label><label>Número de cuotas*<select name="installments"><?php for($i=1;$i<=24;$i++): ?><option><?=$i?></option><?php endfor; ?></select></label><label>Fecha de inicio*<input type="text" name="start_date" value="<?=e(date('d/m/y'))?>" placeholder="dd/mm/yy" inputmode="numeric" pattern="[0-9]{2}/[0-9]{2}/[0-9]{2}" maxlength="8" required></label></div>
<h3>Productos</h3><div id="items"></div><button type="button" class="btn secondary" onclick="addRow()">+ Agregar producto</button>
<div class="two" style="margin-top:15px"><label>Total<input id="total" readonly></label><label>Cuota aproximada<input id="installment" readonly></label></div>
<label>Notas<textarea name="notes"></textarea></label><button type="submit" class="btn primary">Crear pedido</button>
</form></div>
<script>
const clients=<?=json_encode($clients,JSON_UNESCAPED_UNICODE)?>;
const products=<?=json_encode($products,JSON_UNESCAPED_UNICODE)?>;
const clientSearch=document.getElementById('clientSearch'),clientId=document.getElementById('clientId'),clientSuggestions=document.getElementById('clientSuggestions');
function showClients(){const q=clientSearch.value.trim().toLowerCase();clientSuggestions.innerHTML='';if(!q){clientSuggestions.style.display='none';return}const matches=clients.filter(c=>String(c.full_name).toLowerCase().includes(q)).slice(0,20);matches.forEach(c=>{const b=document.createElement('button');b.type='button';b.textContent=c.full_name;b.style.cssText='display:block;width:100%;text-align:left;border:0;background:#fff;padding:10px;cursor:pointer';b.onmousedown=e=>{e.preventDefault();clientSearch.value=c.full_name;clientId.value=c.id;clientSuggestions.style.display='none'};clientSuggestions.appendChild(b)});clientSuggestions.style.display=matches.length?'block':'none'}
clientSearch.addEventListener('input',()=>{clientId.value='';showClients()});
clientSearch.addEventListener('focus',showClients);
document.addEventListener('click',e=>{if(!e.target.closest('.predictive-client'))clientSuggestions.style.display='none'});

function addRow(){const wrap=document.getElementById('items'),d=document.createElement('div');d.className='product-row';d.innerHTML=`<label>Producto<select name="product_id[]" onchange="pick(this)"><option value="">Seleccionar</option>${products.map(p=>`<option value="${p.id}" data-name="${esc(p.name)}" data-cash="${p.cash_price}" data-credit="${p.credit_price}" data-stock="${p.stock}">${esc(p.name)} — stock: ${p.stock}</option>`).join('')}</select><input type="hidden" name="product_name[]"></label><label>Cantidad<input type="number" min="1" value="1" name="qty[]" oninput="calc()"></label><label>Precio unitario<input type="number" step="0.01" min="0" name="unit_price[]" readonly></label><button type="button" class="btn danger" onclick="this.parentElement.remove();calc()">×</button>`;wrap.appendChild(d)}
function esc(s){return String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;')}
function pick(s){const o=s.options[s.selectedIndex],r=s.closest('.product-row'),n=parseInt(document.querySelector('[name="installments"]').value)||1;r.querySelector('[name="product_name[]"]').value=o.dataset.name||'';r.querySelector('[name="unit_price[]"]').value=n===1?(o.dataset.cash||0):(o.dataset.credit||0);r.querySelector('[name="qty[]"]').max=o.dataset.stock||0;calc()}
function updatePrices(){document.querySelectorAll('.product-row select').forEach(pick);}
function calc(){let t=0;document.querySelectorAll('.product-row').forEach(r=>t+=(parseFloat(r.querySelector('[name="qty[]"]').value)||0)*(parseFloat(r.querySelector('[name="unit_price[]"]').value)||0));const n=parseInt(document.querySelector('[name="installments"]').value)||1;document.getElementById('total').value='S/ '+t.toFixed(2);document.getElementById('installment').value='S/ '+(t/n).toFixed(2)}
document.querySelector('[name="installments"]').onchange=updatePrices;addRow();
</script>
<?php require 'footer.php'; ?>
