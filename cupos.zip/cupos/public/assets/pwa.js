(function () {
  if (!('serviceWorker' in navigator)) return;

  window.addEventListener('load', function () {
    navigator.serviceWorker.register('service-worker.js', { scope: './' }).catch(function (error) {
      console.warn('PWA: no se pudo registrar el Service Worker.', error);
    });
  });

  let deferredPrompt = null;

  window.addEventListener('beforeinstallprompt', function (event) {
    event.preventDefault();
    deferredPrompt = event;

    let button = document.getElementById('installAppBtn');
    if (!button) {
      button = document.createElement('button');
      button.id = 'installAppBtn';
      button.type = 'button';
      button.className = 'btn secondary pwa-install';
      button.textContent = 'Instalar app';
      const nav = document.querySelector('.nav');
      if (nav) nav.appendChild(button);
    }

    button.hidden = false;
    button.addEventListener('click', async function () {
      if (!deferredPrompt) return;
      deferredPrompt.prompt();
      await deferredPrompt.userChoice;
      deferredPrompt = null;
      button.hidden = true;
    }, { once: true });
  });

  window.addEventListener('appinstalled', function () {
    const button = document.getElementById('installAppBtn');
    if (button) button.hidden = true;
    deferredPrompt = null;
  });
})();
