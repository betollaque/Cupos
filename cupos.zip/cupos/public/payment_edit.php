<?php
require_once __DIR__.'/../includes/auth.php';
require_once __DIR__.'/../includes/helpers.php';
require_login();
$pdo = db();
$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$st = $pdo->prepare('SELECT p.*, o.total, o.id AS oid FROM payments p JOIN orders o ON o.id=p.order_id WHERE p.id=?');
$st->execute([$id]);
$p = $st->fetch();
if (!$p) { $_SESSION['flash'] = 'No se encontró el pago.'; redirect('orders.php'); }
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $dateInput = trim($_POST['paid_at'] ?? '');
    $date = date_to_db($dateInput);
    $amount = (float)($_POST['amount'] ?? 0);
    $late = max(0, (float)($_POST['late_fee'] ?? 0));
    $obs = trim($_POST['observation'] ?? '');
    if (!$date || $amount <= 0) {
        $_SESSION['flash'] = 'Verifica la fecha y el monto del pago.';
        redirect('payment_edit.php?id='.$id);
    }
    $st = $pdo->prepare('SELECT COALESCE(SUM(amount),0) FROM payments WHERE order_id=? AND id<>?');
    $st->execute([$p['oid'], $id]);
    $otherPaid = (float)$st->fetchColumn();
    $maxAmount = max(0, (float)$p['total'] - $otherPaid);
    if ($amount > $maxAmount + 0.00001) {
        $_SESSION['flash'] = 'El monto supera el saldo disponible del pedido: '.money($maxAmount);
        redirect('payment_edit.php?id='.$id);
    }
    $st = $pdo->prepare('UPDATE payments SET paid_at=?, amount=?, late_fee=?, observation=? WHERE id=?');
    $st->execute([$date, $amount, $late, $obs, $id]);
    $st = $pdo->prepare("UPDATE orders SET status=CASE WHEN (SELECT COALESCE(SUM(amount),0) FROM payments WHERE order_id=?) >= total THEN 'completed' ELSE 'pending' END WHERE id=?");
    $st->execute([$p['oid'], $p['oid']]);
    $_SESSION['flash'] = 'Pago actualizado correctamente.';
    redirect('order.php?id='.$p['oid']);
}
require 'header.php';
?>
<h1>Editar pago — Cuota <?= (int)$p['installment_no'] ?></h1>
<div class="card">
  <form method="post">
    <input type="hidden" name="id" value="<?= (int)$id ?>">
    <div class="four">
      <label>Fecha<input type="date" name="paid_at" value="<?= e(date_to_db($p['paid_at']) ?: '') ?>" required></label>
      <label>Monto<input type="number" name="amount" step="0.01" min="0.01" value="<?= e($p['amount']) ?>" required></label>
      <label>Mora<input type="number" name="late_fee" step="0.01" min="0" value="<?= e($p['late_fee']) ?>"></label>
      <label>Observación<input name="observation" maxlength="255" value="<?= e($p['observation'] ?? '') ?>"></label>
    </div>
    <div class="actions"><button class="btn primary" type="submit">Guardar cambios</button><a class="btn secondary" href="order.php?id=<?= (int)$p['oid'] ?>">Cancelar</a></div>
  </form>
</div>
<?php require 'footer.php'; ?>
