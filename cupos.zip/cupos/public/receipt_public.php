<?php
require_once __DIR__.'/../includes/db.php';
require_once __DIR__.'/../includes/helpers.php';

$id=(int)($_GET['id']??0);
$token=$_GET['token']??'';
$expected=hash_hmac('sha256',(string)$id,APP_URL.DB_NAME.DB_USER);
if($id<=0 || !hash_equals($expected,$token)){
    http_response_code(403);
    echo '<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Comprobante</title><link rel="stylesheet" href="assets/style.css"></head><body><div class="alert danger">Enlace de comprobante no válido o caducado.</div></body></html>';
    exit;
}
$st=db()->prepare('SELECT p.*,o.order_number,o.total,o.installments,c.full_name,c.district,c.phone,c.email FROM payments p JOIN orders o ON o.id=p.order_id JOIN clients c ON c.id=o.client_id WHERE p.id=?');
$st->execute([$id]);
$p=$st->fetch();
if(!$p){
    http_response_code(404);
    echo '<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Comprobante</title><link rel="stylesheet" href="assets/style.css"></head><body><div class="alert danger">Comprobante no encontrado.</div></body></html>';
    exit;
}
$st=$pdo=null;
$st=db()->prepare('SELECT oi.product_name,oi.quantity FROM order_items oi WHERE oi.order_id=(SELECT order_id FROM payments WHERE id=?)');
$st->execute([$id]);$items=$st->fetchAll();
$st=db()->prepare('SELECT COALESCE(SUM(amount),0) FROM payments WHERE order_id=? AND id<=?');
$st->execute([$p['order_id'],$id]);$paidSoFar=(float)$st->fetchColumn();
$balance=max(0,(float)$p['total']-$paidSoFar);
$productText=implode(' · ',array_map(fn($x)=>$x['quantity'].' x '.$x['product_name'],$items));
$d=strtotime($p['paid_at']);
?>
<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Comprobante <?=e($p['order_number'])?> - Cuota <?=e($p['installment_no'])?></title>
<link rel="stylesheet" href="assets/style.css">
<style>
@media print{
  .print-actions{display:none!important}
  body{background:#fff!important}
  .receipt{margin:0!important;box-shadow:none!important}
}
</style>
</head>
<body>
<div class="print-actions">
  <button class="btn primary" onclick="window.print()">Descargar / Guardar PDF</button>
</div>
<div class="receipt" id="receiptToPrint">
 <div class="receipt-header"><div class="receipt-brand"><img src="../assets/logo.png" alt="JR Electronyx"><div class="receipt-title">Comprobante de pago</div></div><div class="receipt-company"><?=e(COMPANY_NAME)?><br><span style="font-size:13px;font-weight:600">RUC 20562962809</span></div></div>
 <div class="receipt-grid"><div class="receipt-cell"><div class="receipt-label">N° de cupones</div><div class="receipt-value"><?=e($p['order_number'])?> / C<?=$p['installment_no']?></div></div><div class="receipt-cell"><div class="receipt-label">Fecha</div><div class="receipt-value"><?=date('d/m/y',$d)?></div></div></div>
 <div class="receipt-client"><div class="receipt-cell"><div class="receipt-label">Cliente:</div><div class="receipt-value"><?=e($p['full_name'])?></div><div class="receipt-label" style="margin-top:8px">Distrito:</div><div class="receipt-value"><?=e($p['district'])?></div></div><div class="receipt-cell"><div style="display:flex;gap:24px;align-items:flex-start;flex-wrap:wrap"><div><div class="receipt-label">Monto:</div><div class="receipt-value"><?=money($p['amount'])?></div></div><div><div class="receipt-label">Mora:</div><div class="receipt-value"><?=money($p['late_fee'])?></div></div></div><div class="receipt-label" style="margin-top:8px">Observación:</div><div class="receipt-value"><?=e($p['observation'])?></div></div></div>
 <div class="receipt-products"><div class="receipt-label">Producto:</div><div class="receipt-value"><?=e($productText)?></div></div>
 <div class="receipt-footer"><div class="contact">📍 <?=e(COMPANY_ADDRESS)?><br>☎ <?=e(COMPANY_PHONES)?><br>🌐 <?=e(COMPANY_WEB)?><br>✉ <?=e(COMPANY_EMAIL)?></div><div class="balance"><b>Cuota:</b> <?=$p['installment_no']?> de <?=$p['installments']?><br><b>Saldo:</b> <?=money($balance)?></div></div>
 <div class="slogan">“<?=e(COMPANY_MESSAGE)?>”</div>
</div>
</body></html>
