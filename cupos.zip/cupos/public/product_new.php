<?php
require_once __DIR__.'/../includes/auth.php';
require_once __DIR__.'/../includes/helpers.php';
require_login();
$pdo = db();
$id = (int)($_GET['id'] ?? 0);
$p = $id ? $pdo->query('SELECT * FROM products WHERE id='.$id)->fetch() : null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $cash = (float)($_POST['cash_price'] ?? 0);
    $credit = (float)($_POST['credit_price'] ?? 0);
    $stock = max(0, (int)($_POST['stock'] ?? 0));
    $min_stock = max(0, (int)($_POST['min_stock'] ?? 0));
    $active = isset($_POST['active']) ? 1 : 0;
    $supplier = trim($_POST['supplier'] ?? '');
    if ($id) {
        $st = $pdo->prepare('UPDATE products SET name=?,supplier=?,price=?,cash_price=?,credit_price=?,stock=?,min_stock=?,active=? WHERE id=?');
        $st->execute([trim($_POST['name']), $supplier, $cash, $cash, $credit, $stock, $min_stock, $active, $id]);
    } else {
        $st = $pdo->prepare('INSERT INTO products(name,supplier,price,cash_price,credit_price,stock,min_stock,active) VALUES(?,?,?,?,?,?,?,?)');
        $st->execute([trim($_POST['name']), $supplier, $cash, $cash, $credit, $stock, $min_stock, $active]);
    }
    flash($id ? 'Producto actualizado correctamente.' : 'Producto guardado correctamente.');
    redirect('products.php');
}
require 'header.php';
?>
<h1><?=$id?'Editar':'Nuevo'?> producto</h1>
<div class="card"><form method="post" data-confirm-save data-confirm-title="Confirmar producto" data-confirm-text="¿Deseas guardar este producto? Al confirmar se guardará y volverás a la pantalla de Almacén.">
<div class="two">
<label>Nombre*<input name="name" required value="<?=e($p['name']??'')?>"></label>
<label>Proveedor<input name="supplier" value="<?=e($p['supplier']??'')?>" placeholder="Nombre del proveedor"></label>
</div>
<div class="two">
<label>Precio contado<input type="number" step="0.01" min="0" name="cash_price" value="<?=e($p['cash_price']??$p['price']??'0')?>"></label>
<label>Precio crédito<input type="number" step="0.01" min="0" name="credit_price" value="<?=e($p['credit_price']??$p['price']??'0')?>"></label>
</div>
<div class="two">
<label>Stock<input type="number" step="1" min="0" name="stock" value="<?=e($p['stock']??'0')?>"></label>
<label>Stock mínimo<input type="number" step="1" min="0" name="min_stock" value="<?=e($p['min_stock']??'0')?>"></label>
</div>
<label><input style="width:auto" type="checkbox" name="active" <?=$p ? ($p['active']?'checked':'') : 'checked'?>> Activo</label>
<div class="actions"><button type="submit" class="btn primary">Guardar</button><a class="btn secondary" href="products.php">Cancelar</a></div>
</form></div>
<?php require 'footer.php'; ?>
