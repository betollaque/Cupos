<?php
// ===== CONFIGURACIÓN =====
define('DB_HOST', 'localhost');
define('DB_NAME', 'vigose5_cupos');
define('DB_USER', 'vigose5_beto');
define('DB_PASS', '97648888');

// URL pública, sin / final. Ejemplo: https://tudominio.com/cuotas
// Debe apuntar a la carpeta public/ si public/ es el DocumentRoot, o a la ruta correspondiente.
define('APP_URL', 'https://ecbiz222.inmotionhosting.com/~vigose5/jrelectronyx/cupos/public');

define('COMPANY_NAME', 'J.R. ELECTRONYX S.A.C.');
define('COMPANY_ADDRESS', 'Jr Rio Oxapampa 646, Los Olivos');
define('COMPANY_PHONES', '984151906 - 967777515');
define('COMPANY_WEB', 'www.electronyx.com.pe');
define('COMPANY_EMAIL', 'jrelectronyx@gmail.com');
define('COMPANY_MESSAGE', 'NO PIERDA SU CRÉDITO SIENDO UN BUEN CLIENTE PAGANDO PUNTUAL');

// ===== CORREO SMTP =====
// SMTP está activado. Reemplaza los valores de ejemplo por los datos reales de tu hosting.
define('SMTP_ENABLED', true);
define('SMTP_HOST', 'mail.warcoglobal.com');
define('SMTP_PORT', 465);
define('SMTP_SECURE', 'ssl'); // 465=SSL. Para 587 usa 'tls'.
define('SMTP_USER', 'noreply@warcoglobal.com');
define('SMTP_PASS', 'Ry*OokoimgX2');
// El remitente SMTP se toma de SMTP_USER para evitar rechazos de cPanel.
// SMTP_FROM_EMAIL se conserva por compatibilidad, pero no se usa como MAIL FROM.
define('SMTP_FROM_EMAIL', SMTP_USER);
define('SMTP_FROM_NAME', COMPANY_NAME);

date_default_timezone_set('America/Lima');

if (session_status() !== PHP_SESSION_ACTIVE) session_start();
