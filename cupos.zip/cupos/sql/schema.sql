CREATE DATABASE IF NOT EXISTS cuotas_jr CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE cuotas_jr;

CREATE TABLE admins (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE clients (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(160) NOT NULL,
  document VARCHAR(30) NULL,
  district VARCHAR(100) NULL,
  phone VARCHAR(30) NULL,
  email VARCHAR(160) NULL,
  address VARCHAR(255) NULL,
  notes TEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_client_name(full_name)
) ENGINE=InnoDB;

CREATE TABLE products (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(180) NOT NULL,
  supplier VARCHAR(180) NULL,
  price DECIMAL(12,2) NOT NULL DEFAULT 0,
  cash_price DECIMAL(12,2) NOT NULL DEFAULT 0,
  credit_price DECIMAL(12,2) NOT NULL DEFAULT 0,
  stock INT NOT NULL DEFAULT 0,
  min_stock INT NOT NULL DEFAULT 0,
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE orders (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_number VARCHAR(40) NOT NULL UNIQUE,
  client_id INT UNSIGNED NOT NULL,
  total DECIMAL(12,2) NOT NULL,
  installments INT UNSIGNED NOT NULL,
  installment_amount DECIMAL(12,2) NOT NULL,
  start_date DATE NOT NULL,
  notes TEXT NULL,
  status ENUM('active','completed','cancelled') NOT NULL DEFAULT 'active',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (client_id) REFERENCES clients(id)
) ENGINE=InnoDB;

CREATE TABLE order_items (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_id INT UNSIGNED NOT NULL,
  product_id INT UNSIGNED NULL,
  product_name VARCHAR(180) NOT NULL,
  quantity INT UNSIGNED NOT NULL DEFAULT 1,
  unit_price DECIMAL(12,2) NOT NULL,
  subtotal DECIMAL(12,2) NOT NULL,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE payments (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_id INT UNSIGNED NOT NULL,
  installment_no INT UNSIGNED NOT NULL,
  paid_at DATE NOT NULL,
  amount DECIMAL(12,2) NOT NULL,
  late_fee DECIMAL(12,2) NOT NULL DEFAULT 0,
  observation VARCHAR(255) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  UNIQUE KEY uq_order_installment(order_id, installment_no)
) ENGINE=InnoDB;

INSERT INTO admins(username,password_hash) VALUES ('admin', '$2y$12$/O65fI04IRQnpiYifxg3Hu8k5CwDn70XhG.v0w3ClgnWfgJg7rFk6');
INSERT INTO products(name,supplier,price,cash_price,credit_price,stock,min_stock) VALUES
('Celular',NULL,0,0,0,0,0),('TV',NULL,0,0,0,0,0),('Computadora',NULL,0,0,0,0,0),('Laptop',NULL,0,0,0,0,0),('Equipo de sonido',NULL,0,0,0,0,0),('Lavadora',NULL,0,0,0,0,0),('Cocina',NULL,0,0,0,0,0),('Refrigeradora',NULL,0,0,0,0,0),('Congeladora',NULL,0,0,0,0,0),('Juego de ollas',NULL,0,0,0,0,0),('Licuadora',NULL,0,0,0,0,0),('Batidora',NULL,0,0,0,0,0),('Vajilla en acero',NULL,0,0,0,0,0),('Cámaras de vigilancia',NULL,0,0,0,0,0),('Muebles',NULL,0,0,0,0,0),('Juego de comedores',NULL,0,0,0,0,0),('Sillas gamer',NULL,0,0,0,0,0),('Módulos',NULL,0,0,0,0,0),('Camas',NULL,0,0,0,0,0),('Colchón',NULL,0,0,0,0,0),('Zapatillas deportivas',NULL,0,0,0,0,0),('Artículos de belleza',NULL,0,0,0,0,0),('Otros',NULL,0,0,0,0,0);
