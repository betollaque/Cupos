-- Nuevos campos para Almacén / Productos
ALTER TABLE products
  ADD COLUMN cash_price DECIMAL(12,2) NOT NULL DEFAULT 0 AFTER price,
  ADD COLUMN credit_price DECIMAL(12,2) NOT NULL DEFAULT 0 AFTER cash_price,
  ADD COLUMN stock INT NOT NULL DEFAULT 0 AFTER credit_price,
  ADD COLUMN min_stock INT NOT NULL DEFAULT 0 AFTER stock;

-- Copia el precio actual a precio contado y precio crédito para conservar los datos existentes.
UPDATE products
SET cash_price = price,
    credit_price = price
WHERE cash_price = 0 AND credit_price = 0;
