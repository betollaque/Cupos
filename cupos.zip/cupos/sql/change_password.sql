-- Genera el hash con PHP: php -r "echo password_hash('TU_NUEVA_CLAVE', PASSWORD_DEFAULT), PHP_EOL;"
-- Luego reemplaza el valor siguiente:
UPDATE admins SET password_hash='PEGA_AQUI_EL_HASH_BCRYPT' WHERE username='admin';
