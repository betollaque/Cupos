# Sistema de Control de Cuotas - JR Electronyx

Sistema web PHP + MySQL pensado para hosting compartido (cPanel o similar).

## Incluye
- Un único usuario administrador.
- Clientes.
- Catálogo de productos.
- Pedidos con varios productos.
- Hasta 24 cuotas mensuales.
- Cálculo automático de cuota.
- Registro de pagos y mora opcional.
- Saldo actualizado.
- Comprobante mensual con el formato basado en la foto proporcionada.
- Envío por WhatsApp mediante enlace con el comprobante público.
- Envío por correo usando `mail()` de PHP.
- Historial de pagos.
- Diseño responsive.

## Instalación
1. Crea una base de datos MySQL en tu hosting.
2. Importa `sql/schema.sql`.
3. Edita `config/config.php` con las credenciales MySQL y la URL pública del sistema.
4. Sube todos los archivos respetando las carpetas.
5. Abre `/public/`.
6. Usuario inicial: `admin`
7. Contraseña inicial: `admin123`
8. Cambia la contraseña directamente en MySQL usando el hash indicado en `sql/change_password.sql` o, preferiblemente, ejecuta el hash generado por PHP.

## Importante sobre WhatsApp
El sistema no necesita API de WhatsApp para funcionar. Genera un enlace `wa.me` con el mensaje y URL del comprobante. Al pulsarlo, WhatsApp se abre con el mensaje preparado. El administrador debe pulsar Enviar.

Para automatización 100% sin intervención se necesitaría WhatsApp Business Cloud API.

## Correo
El sistema usa `mail()` de PHP para evitar dependencias externas. En algunos hostings debe configurarse el correo saliente. Para producción se recomienda SMTP con PHPMailer.

## Comprobante
`public/receipt.php` genera una versión imprimible. El botón de impresión permite Guardar como PDF desde Chrome/Edge. La URL también puede enviarse por WhatsApp o correo.


## SMTP / cPanel
- Para cPanel, usa normalmente SMTP_USER como cuenta completa, puerto 465 con SSL o 587 con STARTTLS.
- El sistema usa SMTP_USER como MAIL FROM para evitar el rechazo que ocurre cuando se intenta enviar con una dirección distinta a la cuenta autenticada.
- Si el servidor rechaza el mensaje después de DATA, ahora se muestra la respuesta SMTP real para identificar la causa.
